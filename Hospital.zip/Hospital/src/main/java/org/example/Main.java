package org.example;

import com.mysql.cj.jdbc.exceptions.PacketTooBigException;
import jakarta.persistence.EntityManagerFactory;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import javax.print.Doc;
import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) throws IllegalAccessException {
        Doctor doctor = new Doctor();
        Patient patient = new Patient();
        Appointment appointment = new Appointment();
        Diagnosis diagnosis = new Diagnosis();
        final org.hibernate.SessionFactory sessionFactory = new Configuration()
                .configure("hibernate.cfg.xml")
                .addAnnotatedClass(Doctor.class)
                .addAnnotatedClass(Patient.class)
                .addAnnotatedClass(Appointment.class)
                .addAnnotatedClass(Diagnosis.class)
                .buildSessionFactory();

        System.out.println("Please press:" + '\n' +
                "1 for the list of doctors in a certain address" + '\n' +
                "2 for the list of doctors with a certain specialization" + '\n' +
                "3 for the list of patients older than a certain age" + '\n' +
                "4 for the list of patients with a certain id and their corresponding doctors" + '\n' +
                "5 for the list of appointments with a certain symptom" + '\n' +
                "6 for the list of diagnosis");
        Scanner scanner = new Scanner(System.in);
        String input = scanner.nextLine();
        if (!input.equals(1) && !input.equals(2) && !input.equals(3)
        && !input.equals(4) && !input.equals(5) && !input.equals(6)){
            System.out.println("The value you entered is invalid");
        }
        switch (input){
            case "1":
                System.out.println("Please enter the doctor's address");
                Scanner scanner1 = new Scanner(System.in);
                String input1 = scanner1.nextLine();
                DoctorRepository doctorRepository1 = new DoctorRepository
                        (sessionFactory.createEntityManager());
                List<Doctor> doctorsInBuildingB = doctorRepository1.
                        getDoctorsInAddress(input1);
                StringBuilder sb1 = new StringBuilder();
                for (Doctor doctor1: doctorsInBuildingB) {
                    sb1.append(doctor1.toString()).append("\n");}
                System.out.println(sb1.toString());break;
            case "2":
                System.out.println("Please enter the doctor's specialization");
                Scanner scanner2 = new Scanner(System.in);
                String input2 = scanner2.nextLine();
                DoctorRepository doctorRepository2 = new DoctorRepository(sessionFactory.createEntityManager());
                List<Doctor> doctorsWithSpecialization = doctorRepository2.
                        getDoctorsWithSpecialization(input2);
                StringBuilder sb2 = new StringBuilder();
                for (Doctor doctor2: doctorsWithSpecialization) {
                    sb2.append(doctor2.toString()).append("\n");}
                System.out.println(sb2.toString());break;
            case "3":
                System.out.println("Please enter the patient's age");
                Scanner scanner3 = new Scanner(System.in);
                Integer input3 = scanner3.nextInt();
                PatientRepository patientRepository1 = new PatientRepository(sessionFactory.createEntityManager());
                List<Patient> patientsOlderThan = patientRepository1.
                        getPatientsOlderThan(String.valueOf(input3));
                StringBuilder sb3 = new StringBuilder();
                for (Patient patient1: patientsOlderThan) {
                    sb3.append(patient1.toString()).append("\n");}
                System.out.println(sb3.toString());break;
            case "4":
                System.out.println("Please enter the patient's id");
                Scanner scanner4 = new Scanner(System.in);
                Integer input4 = scanner4.nextInt();
                PatientRepository patientRepository2 = new PatientRepository(sessionFactory.createEntityManager());
                List<Patient> patientsAndDoctorsWithId = patientRepository2.
                        getPatientsAndDoctorsWithId(String.valueOf(input4));
                StringBuilder sb4 = new StringBuilder();
                for (Patient patient2: patientsAndDoctorsWithId) {
                    sb4.append(patient2.toString()).append("\n");}
                System.out.println(sb4.toString());break;
            case "5":
                System.out.println("Please enter the symptom");
                Scanner scanner5 = new Scanner(System.in);
                String input5 = scanner5.nextLine();
                AppointmentRepository appointmentRepository = new AppointmentRepository(sessionFactory.createEntityManager());
                List<Appointment> appointmentWithSymptom = appointmentRepository.
                        getAppointmentWithSymptom(input5);
                StringBuilder sb5 = new StringBuilder();
                for (Appointment appointment1: appointmentWithSymptom) {
                    sb5.append(appointment1.toString()).append("\n");}
                System.out.println(sb5.toString());break;
            case "6":
                System.out.println("Please enter the diagnosis");
                Scanner scanner6 = new Scanner(System.in);
                String input6 = scanner6.nextLine();
                DiagnosisRepository diagnosisRepository = new DiagnosisRepository(sessionFactory.createEntityManager());
                List<Diagnosis> getDiagnosis = diagnosisRepository.getDiagnosis(input6);
                StringBuilder sb6 = new StringBuilder();
                for (Diagnosis diagnosis1: getDiagnosis) {
                    sb6.append(diagnosis1.toString()).append("\n");}
                System.out.println(sb6.toString());break;
        }
    }
}