package org.example;

import jakarta.persistence.EntityManager;

import javax.print.Doc;
import java.sql.*;
import java.util.List;

public class DoctorRepository extends RuntimeException{
    private final EntityManager entityManager;
    public DoctorRepository(EntityManager entityManager) {
        this.entityManager = entityManager;}
    public List<Doctor> getDoctorsInAddress(String address) {
        return entityManager.createQuery("FROM Doctor d WHERE d.address = :address",
                        Doctor.class).setParameter("address", address).getResultList();}
    public List<Doctor> getDoctorsWithSpecialization(String specialization) {
        return entityManager.createQuery("FROM Doctor d WHERE d.specialization = :specialization",
                Doctor.class).setParameter("specialization", specialization).getResultList();}
}