package org.example;

import jakarta.persistence.EntityManager;

import java.util.List;

public class DiagnosisRepository extends RuntimeException{
    private final EntityManager entityManager;
    public DiagnosisRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public List<Diagnosis> getDiagnosis(String diagnosis){
        return entityManager.createQuery("FROM Diagnosis d where d.diagnosis = :diagnosis",
                        Diagnosis.class)
                .setParameter("diagnosis", diagnosis).getResultList();
    }
}