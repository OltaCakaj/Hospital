package org.example;

import jakarta.persistence.EntityManager;

import javax.swing.*;
import java.util.List;

public class PatientRepository extends RuntimeException{
    private final EntityManager entityManager;
    public PatientRepository(EntityManager entityManager) {
        this.entityManager = entityManager;}
    public List<Patient> getPatientsOlderThan(String age){
        return entityManager.createQuery("FROM Patient p where p.age > :age",
                        Patient.class)
                .setParameter("age", age).getResultList();}
    public List<Patient> getPatientsAndDoctorsWithId(String id){
        return entityManager.createQuery("FROM Patient p INNER JOIN p.doctor d WHERE p.id = :id",
                        Patient.class)
                .setParameter("id", id).getResultList();}
}