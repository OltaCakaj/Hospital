package org.example;

import jakarta.persistence.EntityManager;

import java.util.List;

public class AppointmentRepository extends RuntimeException{
    private final EntityManager entityManager;
    public AppointmentRepository(EntityManager entityManager) {
        this.entityManager = entityManager;
    }
    public List<Appointment> getAppointmentWithSymptom(String symptom){
        return entityManager.createQuery("FROM Appointment a where a.symptom = :symptom",
                        Appointment.class)
                .setParameter("symptom", symptom).getResultList();
    }
}
